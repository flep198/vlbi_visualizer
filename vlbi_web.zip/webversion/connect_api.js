//Step 1: initialize communication with the platform
// In your own code, replace variable window.apikey with your own apikey
var platform = new H.service.Platform({
  apikey: "V_y0Xkj64LQhjx7ZHPPoFkj4oO9nMnvhXn8O3SUKy5c"
});
